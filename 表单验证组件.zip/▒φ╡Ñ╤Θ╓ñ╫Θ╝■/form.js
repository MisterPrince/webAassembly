$(document).ready(function() {
    $('#defaultForm')
        .bootstrapValidator({
            message: '用户名无效',
            feedbackIcons: {
                valid: 'glyphicon glyphicon-ok',
                invalid: 'glyphicon glyphicon-remove',
                validating: 'glyphicon glyphicon-refresh'
            },
            fields: {
                username: {
                    message: '用户名无效',
                    validators: {
                        notEmpty: {
                            message: '用户名是必需的，不能是空的'
                        },
                        stringLength: {
                            min: 6,
                            max: 30,
                            message: '用户名必须是大于6且小于30个字符'
                        },
                        /*remote: {
                            url: 'remote.php',
                            message: '用户名不可用'
                        },*/
                        regexp: {
                            regexp: /^[a-zA-Z0-9_\.]+$/,
                            message: '用户名只能包含字母、数字和下划线，点'
                        }
                    }
                },
                email: {
                    validators: {
                        notEmpty: {
                            message: '电子邮件地址是必需的，不能是空的'
                        },
                        emailAddress: {
                            message: '输入的不是一个有效的电子邮件地址'
                        }
                    }
                },
                password: {
                    validators: {
                        notEmpty: {
                            message: '密码不能为空'
                        }
                    }
                }
            }
        })
        .on('success.form.bv', function(e) {
            // Prevent form submission
            e.preventDefault();

            // Get the form instance
            var $form = $(e.target);

            // Get the BootstrapValidator instance
            var bv = $form.data('bootstrapValidator');

            // Use Ajax to submit form data
            $.post($form.attr('action'), $form.serialize(), function(result) {
                console.log(result);
            }, 'json');
        });
});